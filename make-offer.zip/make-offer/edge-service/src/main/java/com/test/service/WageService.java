package com.test.service;

import com.test.domain.WageEntity;

import java.util.List;

public interface WageService {
    List<WageEntity> findAll();
}
