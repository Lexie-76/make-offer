package com.test.service;

import com.test.domain.PriceEntity;

import java.util.List;

public interface PriceService {
    List<PriceEntity> findAll();
}
